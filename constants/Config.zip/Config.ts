export const API_CONFIG = {
  TMDB_BASE_URL: 'https://api.themoviedb.org/3',
  TMDB_IMAGE_BASE_URL: 'https://image.tmdb.org/t/p',
  TMDB_API_KEY: process.env.EXPO_PUBLIC_TMDB_API_KEY || '3b1e2ac1463b21d1dd303ef5a4e1a0be',
  STREAMING_API_BASE_URL: 'https://streaming-availability.p.rapidapi.com',
  STREAMING_API_KEY: process.env.EXPO_PUBLIC_RAPIDAPI_KEY || 'd133a6302cmsh48a429f89650691p11ee6ejsndf11b621d596',
  SUPABASE_URL: process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://qpbagteymfujpuxbnonk.supabase.co',
  SUPABASE_ANON_KEY: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'sb_secret_lxpoKtgyRfy7xQwOhBXd_w_aYp751Ap',
};

export const IMAGE_SIZES = {
  poster: 'w500',
  backdrop: 'w1280',
  profile: 'w185',
};